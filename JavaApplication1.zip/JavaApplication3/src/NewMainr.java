
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class NewMainr {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Import scanner
        //use scanner to collect input
        //ask for name
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your name");
        String name = input.nextLine();
        //print welcome
        System.out.println("Welcome to my quiz "+name);
        //ask the first question 
        System.out.println("Which team from west africa qualified for the 2018 world cup?");
        String westAfrica = input.nextLine();
        //use if to compare question to correct answer
        int ans1 = 0;
        String westAfrica1 = "nigeria";
        if(westAfrica.equalsIgnoreCase(westAfrica1)) {
            System.out.println("correct");
            ans1 = ans1+1;
        } else {
            System.out.println("wrong");
         ans1 = ans1+0;
        }
        //ask the second question
        System.out.println("Which team from north africa close to algeria qualified for the 2018 world cup?");
        String northAfrica = input.nextLine();
        String northAfrica1 = "egypt";
        //use if to compare question to correct answer
        if(northAfrica.equalsIgnoreCase(northAfrica1)) {
             ans1 = ans1+1;
        } else {
         ans1 = ans1+0;
        }
        //ask the third question
        System.out.println("Which team from east africa close to zambia qualified for the 2018 world cup?");
        String eastAfrica = input.nextLine();
        String eastAfrica1 = "senegal";
        //use if to compare question to correct answer
        if(eastAfrica.equalsIgnoreCase(eastAfrica1)) {
            ans1 = ans1+1;
        } else {
        ans1 = ans1+0;
        }
        //ask the fourth question
        System.out.println("How many times has brazil won the world cup?");
        int brazil = input.nextInt();
        //use if to compare question to correct answer
        int brazil1 = 5;
        if(brazil==brazil1) {
             ans1 = ans1+1;
        } else {
         ans1 = ans1+0;
        }
        //ask the fifth question
        System.out.println("Did germany win the world cup in 2014 true or false?");
        boolean germany = input.nextBoolean();
        //use if to compare question to correct answer
        boolean germany1 = true;
        if(germany==germany1) {
             ans1 = ans1+1;
        } else {
        ans1 = ans1+0;
        }
        //calculate the amount of correct or wrong answers the user gave
       int total = ans1; 
       int total1 = total*100/5;
       
       
        //use if to print out score/100 and grade in words
       if(total <= 1) {
             System.out.println("You got "+total+"/5 You got a percentage of "+total1+"% which is very poor");
        } else if(total <= 2) {
            System.out.println("You got "+total+"/5 You got a percentage of "+total1+"% which is poor");
        } else if(total <= 3) {
            System.out.println("You got "+total+"/5 You got a percentage of "+total1+"% which is good");
        }else if(total <= 4) {
            System.out.println("You got "+total+"/5 You got a percentage of "+total1+"% which is very good");
        }else if(total <= 5) {
            System.out.println("You got got "+total+"/5 You got a percentage of "+total1+"% which is excellent");
        }
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter your name");
//        String b = input.nextLine();
//        System.out.println("Enter your heigth (cm)");
//        double c = input.nextDouble();
//        double d = (b * c)/2;
//        System.out.println("Area of triangle:"+ d+"cm2");
    }
    
}
