
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter your name");
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter your number");
//        int b = input.nextInt();
//        System.out.println("Enter your number2");
//        int c = input.nextInt();
//        if(b == 12 && c == 13) {
//            System.out.print("true");
//        }else if(b == 30 || c == 13){
//            System.out.print("true");
//        }else if(b == 20){
//            System.out.print("true");
//        }else{
//            System.out.print("false");
//        }
        Scanner input = new Scanner(System.in);
       System.out.println("Enter your score");
       int me = input.nextInt();
//       String you = "ibukun";
       if(me == 70 && me <= 100) {
           System.out.println("Excellent");
       } else if(me == 60 && me <= 69) {
           System.out.println("Good");
       } else if(me == 50 && me <= 59) {
           System.out.println("Credit");
       } else if(me == 40 && me <= 49) {
           System.out.println("Pass");
       } else {
       System.out.println("Fail");
       } 
    }
    
}
