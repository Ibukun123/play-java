/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class JavaApplication4 {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
       System.out.println("Enter your score");
       int me = input.nextInt();
//       String you = "ibukun";
       if(me >= 70 && me <= 100) {
           System.out.println("Excellent");
       } else if(me >= 60 && me <70) {
           System.out.println("Good");
       } else if(me == 50 && me <= 59) {
           System.out.println("Credit");
       } else if(me == 40 && me <= 49) {
           System.out.println("Pass");
       } else if (me == 0 && me <= 39) {
       System.out.println("Fail");
       } 
        
    }
    
}
