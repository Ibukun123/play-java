/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        String s1  = "Lagos";
//        String s2 = "lagos";
//        System.out.println(s1.equals(s2));
//        String sport = "Football";
//        System.out.println(sport.charAt(4));
//        System.out.printf("%1.2f", 345.7783);
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your base");
        String b = input.nextLine();
        System.out.println("Enter your heigth");
        String c = input.nextLine();
        int d = 1/2 b * c
    }
    
}
