/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;
//          1. Import scanner
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class JavaApplication5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        olamide();
        // TODO code application logic here
        /** BMI Algorithm
         BMI = weight/height2
         * 1. Import scanner
         * 2. Create a scanner object 
         * 3. Collect the first int input as weight from the user(store in a variable).
         * 3b. Collect another int input as height from the user(store in a variable).
         * 4. Calculate the BMI = weight/height2 (store in a variable)
         * 4a. Create an if statement to check if the user is underweight or overweight
         * 4b. If BMI is below 18.5 print out under weight
         * 4c. If BMI is 18.5 > 29.9 print out normal weight
         * 4d. If BMI is more than 30 print over weight
         * 5. else print  error program did not run
         **/
//        BMI Algorithm
//         BMI = weight/height2

//        2. Create a scanner object 
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter your weight");
////        3. Collect the first double input as weight from the user(store in a variable).
//       double weight = input.nextDouble();
//       System.out.println("Enter your height");
////       3b. Collect another double input as height from the user(store in a variable).
//       double height = input.nextDouble();
////       4. Calculate the BMI = weight/height2 (store in a variable)
//       double bmi = weight/(height*height);
//       
////       4a. Create an if statement to check if the user is underweight or overweight
////       4b. If BMI is below 18.5 print out under weight
//       if(bmi < 18.5) {
//           System.out.printf("You are Under weight Your BMI is %.1f %n", bmi);
//       }
////       4c. If BMI is 18.5 > 24.9 print out normal weight
//       else if(bmi >= 18.5 && bmi <= 24.9) {
//           System.out.printf("You are on a Normal weight Your BMI is %.1f %n", bmi);
//      }
////       4d. If BMI is is 25 > 29.9 print over weight
//       else if(bmi >= 25&& bmi <= 29.9) {
//       System.out.printf("You are Over weight Your BMI is %.1f %n", bmi);
//       }
////       4e. If BMI is more than 30 print obessed
//       else if (bmi >= 30.0) {
//           System.out.printf("You are Obessed Your BMI is %.1f %n", bmi );
//       }
        
    }
    public static void  olamide() {
        System.out.print("ibuykun");
    }
    
}
