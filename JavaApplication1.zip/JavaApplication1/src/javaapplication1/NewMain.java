/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class NewMain {

    /*ln
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("add first number");
        double b = input.nextInt();
        System.out.println("add second number");
        double c = input.nextInt();
        int d = (int) (b / c);
        System.out.println(d);
        int t = 2, a, j, k;
        int r = t + 2;
        System.out.print(r);
        
      
//        String task = "Code     Lagos";
//        System.out.print(task.length());
        
        
       
        
    }
    
}
