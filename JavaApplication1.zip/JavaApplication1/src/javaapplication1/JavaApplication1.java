/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author HP
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your name");
        String b = input.nextLine();
        System.out.println("Enter your occupation");
        String ibkn = input.nextLine();
        System.out.println("Enter your religion");
        String ibkw = input.nextLine();
        System.out.println("Enter your nationality");
        String ibk1 = input.nextLine();
        System.out.println("Enter your State of origin");
        String ibkq = input.nextLine();
        System.out.println("Enter your lga");
        String ibke = input.nextLine();
        System.out.println("Enter your Marital status");
        String ibkr = input.nextLine();
        System.out.println("Enter your hobbies");
        String ibkt = input.nextLine();
        System.out.println("Enter your sex");
        String bk = input.nextLine();
        System.out.println("Enter your age");
        String ibk = input.nextLine();
        System.out.println("Your name is "+b+", you are a "+ibkn+", you are a "+ibkw+
                ", you are from "+ibk1+", you are from "+ibkq+", you are from "+ibke+""
                + ", you are "+ibkr+", you like "+ibkt+", you are a "+bk+", you are "+ibk+".");
    }
    
}
